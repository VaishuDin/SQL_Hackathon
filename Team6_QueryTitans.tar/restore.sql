--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "try final query";
--
-- Name: try final query; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "try final query" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "try final query" OWNER TO postgres;

\unrestrict (null)
\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='try final query'"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: fn_audit_covid_case(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_audit_covid_case() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.hospitalised     IS DISTINCT FROM OLD.hospitalised
    OR NEW.outcome_level_id IS DISTINCT FROM OLD.outcome_level_id THEN
        INSERT INTO covid_case_audit (patient_id, old_hospitalised, new_hospitalised,
                                      old_outcome_level, new_outcome_level)
        VALUES (NEW.patient_id, OLD.hospitalised, NEW.hospitalised,
                OLD.outcome_level_id, NEW.outcome_level_id);
    END IF;
    RETURN NEW;
END
$$;


ALTER FUNCTION public.fn_audit_covid_case() OWNER TO postgres;

--
-- Name: fn_cohort_rates(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cohort_rates(p_dimension text) RETURNS TABLE(group_label text, cohort_patients bigint, hospitalised bigint, hosp_rate_pct numeric)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    IF NOT (p_dimension = ANY (ARRAY['sex','age_range','ms_type','bmi_category',
                                     'dmt_class','report_source'])) THEN
        RAISE EXCEPTION 'Unsupported dimension "%". Use sex, age_range, ms_type, bmi_category, dmt_class or report_source.',
                        p_dimension;
    END IF;

    RETURN QUERY EXECUTE format(
        'SELECT COALESCE(%I::text, ''unknown''),
                COUNT(*),
                COUNT(*) FILTER (WHERE hospitalised),
                ROUND(100.0 * COUNT(*) FILTER (WHERE hospitalised) / COUNT(*), 1)
         FROM v_covid_cohort
         GROUP BY 1
         ORDER BY 1', p_dimension);
END
$$;


ALTER FUNCTION public.fn_cohort_rates(p_dimension text) OWNER TO postgres;

--
-- Name: fn_cooccurring_pairs(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cooccurring_pairs(p_kind text, p_min_patients integer DEFAULT 5) RETURNS TABLE(item_a text, item_b text, patients_with_both bigint, pct_of_cohort numeric)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_cohort bigint;
BEGIN
    SELECT COUNT(*) INTO v_cohort
    FROM covid_case
    WHERE diagnosis IN ('confirmed','suspected');

    IF p_kind = 'symptom' THEN
        RETURN QUERY
        SELECT s1.symptom_name, s2.symptom_name, COUNT(*),
               ROUND(100.0 * COUNT(*) / v_cohort, 1)
        FROM patient_symptom a
        JOIN patient_symptom b ON b.patient_id = a.patient_id AND a.symptom_id < b.symptom_id
        JOIN symptom s1 ON s1.symptom_id = a.symptom_id
        JOIN symptom s2 ON s2.symptom_id = b.symptom_id
        JOIN covid_case cc ON cc.patient_id = a.patient_id
        WHERE a.present AND b.present
          AND cc.diagnosis IN ('confirmed','suspected')
        GROUP BY s1.symptom_name, s2.symptom_name
        HAVING COUNT(*) >= p_min_patients
        ORDER BY 3 DESC, 1, 2;

    ELSIF p_kind = 'comorbidity' THEN
        RETURN QUERY
        SELECT m1.comorbidity_name, m2.comorbidity_name, COUNT(*),
               ROUND(100.0 * COUNT(*) / v_cohort, 1)
        FROM patient_comorbidity a
        JOIN patient_comorbidity b ON b.patient_id = a.patient_id AND a.comorbidity_id < b.comorbidity_id
        JOIN comorbidity m1 ON m1.comorbidity_id = a.comorbidity_id
        JOIN comorbidity m2 ON m2.comorbidity_id = b.comorbidity_id
        JOIN covid_case cc ON cc.patient_id = a.patient_id
        WHERE a.present AND b.present
          AND cc.diagnosis IN ('confirmed','suspected')
        GROUP BY m1.comorbidity_name, m2.comorbidity_name
        HAVING COUNT(*) >= p_min_patients
        ORDER BY 3 DESC, 1, 2;

    ELSE
        RAISE EXCEPTION 'Unsupported kind "%". Use symptom or comorbidity.', p_kind;
    END IF;
END
$$;


ALTER FUNCTION public.fn_cooccurring_pairs(p_kind text, p_min_patients integer) OWNER TO postgres;

--
-- Name: fn_odds_ratio(bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_odds_ratio(exp_hosp bigint, exp_n bigint, ref_hosp bigint, ref_n bigint) RETURNS TABLE(odds_ratio numeric, ci_low numeric, ci_high numeric)
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    a numeric := exp_hosp;               -- exposed, hospitalised
    b numeric := exp_n - exp_hosp;       -- exposed, not hospitalised
    c numeric := ref_hosp;               -- reference, hospitalised
    d numeric := ref_n - ref_hosp;       -- reference, not hospitalised
    v_se numeric;
    v_or numeric;
BEGIN
    IF a = 0 OR b = 0 OR c = 0 OR d = 0 THEN
        a := a + 0.5;  b := b + 0.5;  c := c + 0.5;  d := d + 0.5;
    END IF;

    v_or := (a * d) / (b * c);
    v_se := SQRT(1/a + 1/b + 1/c + 1/d);

    RETURN QUERY
    SELECT ROUND(v_or, 2),
           ROUND(EXP(LN(v_or) - 1.96 * v_se), 2),
           ROUND(EXP(LN(v_or) + 1.96 * v_se), 2);
END
$$;


ALTER FUNCTION public.fn_odds_ratio(exp_hosp bigint, exp_n bigint, ref_hosp bigint, ref_n bigint) OWNER TO postgres;

--
-- Name: fn_patient_profile(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_patient_profile(p_patient_id text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
    SELECT jsonb_build_object(
        'patient_id',    p.patient_id,
        'report_source', p.report_source,
        'sex',           p.sex,
        'age_range',     ag.age_range,
        'ms_type',       p.ms_type,
        'dmt',           COALESCE(d.dmt_name, 'unknown'),
        'diagnosis',     cc.diagnosis,
        'outcome',       ol.outcome_desc,
        'symptoms',      COALESCE((SELECT jsonb_agg(s.symptom_name ORDER BY s.symptom_name)
                                   FROM patient_symptom ps
                                   JOIN symptom s ON s.symptom_id = ps.symptom_id
                                   WHERE ps.patient_id = p.patient_id AND ps.present),
                                  '[]'::jsonb),
        'comorbidities', COALESCE((SELECT jsonb_agg(m.comorbidity_name ORDER BY m.comorbidity_name)
                                   FROM patient_comorbidity pc
                                   JOIN comorbidity m ON m.comorbidity_id = pc.comorbidity_id
                                   WHERE pc.patient_id = p.patient_id AND pc.present),
                                  '[]'::jsonb)
    )
    FROM patient p
    JOIN covid_case    cc ON cc.patient_id       = p.patient_id
    JOIN age_group     ag ON ag.age_group_id     = p.age_group_id
    JOIN outcome_level ol ON ol.outcome_level_id = cc.outcome_level_id
    LEFT JOIN dmt_drug d  ON d.dmt_id            = p.dmt_id
    WHERE p.patient_id = p_patient_id
$$;


ALTER FUNCTION public.fn_patient_profile(p_patient_id text) OWNER TO postgres;

--
-- Name: fn_risk_band(bigint, bigint, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_risk_band(p_hosp bigint, p_n bigint, p_baseline_pct numeric) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
    SELECT CASE
             WHEN p_n < 10                                      THEN 'Insufficient data (n<10)'
             WHEN 100.0 * p_hosp / p_n >= p_baseline_pct * 1.25 THEN 'Higher than cohort'
             WHEN 100.0 * p_hosp / p_n <= p_baseline_pct * 0.75 THEN 'Lower than cohort'
             ELSE 'Similar to cohort'
           END
$$;


ALTER FUNCTION public.fn_risk_band(p_hosp bigint, p_n bigint, p_baseline_pct numeric) OWNER TO postgres;

--
-- Name: fn_severity_category(boolean, boolean, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_severity_category(p_hospitalised boolean, p_icu boolean, p_ventilated boolean) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
    SELECT CASE
             WHEN p_icu IS TRUE OR p_ventilated IS TRUE THEN 'ICU and/or ventilation'
             WHEN p_hospitalised IS TRUE                THEN 'Hospitalised'
             WHEN p_hospitalised IS FALSE AND p_icu IS FALSE AND p_ventilated IS FALSE
                                                        THEN 'Not hospitalised'
             ELSE 'Unknown or inconsistent'
           END
$$;


ALTER FUNCTION public.fn_severity_category(p_hospitalised boolean, p_icu boolean, p_ventilated boolean) OWNER TO postgres;

--
-- Name: fn_sync_outcome_level(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_sync_outcome_level() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.outcome_level_id IS DISTINCT FROM 3 THEN        -- never overwrite "died"
        NEW.outcome_level_id := CASE
            WHEN NEW.icu_stay IS TRUE OR NEW.ventilated IS TRUE THEN 2
            WHEN NEW.hospitalised IS TRUE                       THEN 1
            ELSE 0
        END;
    END IF;
    RETURN NEW;
END
$$;


ALTER FUNCTION public.fn_sync_outcome_level() OWNER TO postgres;

--
-- Name: fn_validate_covid_case(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_validate_covid_case() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (NEW.icu_stay IS TRUE OR NEW.ventilated IS TRUE)
       AND NEW.hospitalised IS NOT TRUE THEN
        RAISE EXCEPTION 'Invalid case %: ICU/ventilation recorded without hospital admission',
                        NEW.patient_id;
    END IF;
    RETURN NEW;
END
$$;


ALTER FUNCTION public.fn_validate_covid_case() OWNER TO postgres;

--
-- Name: sp_refresh_outcome_summary(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_refresh_outcome_summary()
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_dim  text;
    v_rows integer;
BEGIN
    TRUNCATE rpt_outcome_summary;

    FOREACH v_dim IN ARRAY ARRAY['sex','age_range','ms_type','bmi_category',
                                 'dmt_class','report_source'] LOOP
        INSERT INTO rpt_outcome_summary (dimension, group_label, cohort_patients,
                                         hospitalised, hosp_rate_pct)
        SELECT v_dim, group_label, cohort_patients, hospitalised, hosp_rate_pct
        FROM fn_cohort_rates(v_dim);
    END LOOP;

    SELECT COUNT(*) INTO v_rows FROM rpt_outcome_summary;
    RAISE NOTICE 'rpt_outcome_summary refreshed: % rows', v_rows;
END
$$;


ALTER PROCEDURE public.sp_refresh_outcome_summary() OWNER TO postgres;

--
-- Name: sp_run_data_quality_checks(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_run_data_quality_checks()
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_run   timestamptz := clock_timestamp();
    v_total bigint;
BEGIN
    INSERT INTO dq_issue_log (run_at, check_name, issue_count)
    SELECT v_run, '1. Hospitalised but diagnosis is not_suspected', COUNT(*)
    FROM covid_case
    WHERE hospitalised AND diagnosis = 'not_suspected'
    UNION ALL
    SELECT v_run, '2. ICU or ventilation without hospital admission', COUNT(*)
    FROM covid_case
    WHERE (icu_stay IS TRUE OR ventilated IS TRUE) AND hospitalised IS NOT TRUE
    UNION ALL
    SELECT v_run, '3. "No symptoms" but a symptom is yes', COUNT(DISTINCT cc.patient_id)
    FROM covid_case cc
    JOIN patient_symptom ps ON ps.patient_id = cc.patient_id
    WHERE cc.has_symptoms = false AND ps.present
    UNION ALL
    SELECT v_run, '4. Comorbidity flag yes but no condition listed', COUNT(*)
    FROM patient p
    WHERE p.has_comorbidities
      AND NOT EXISTS (SELECT 1
                      FROM patient_comorbidity pc
                      WHERE pc.patient_id = p.patient_id AND pc.present)
    UNION ALL
    SELECT v_run, '5. Pregnancy recorded for a male', COUNT(*)
    FROM patient
    WHERE sex = 'male' AND pregnancy
    UNION ALL
    SELECT v_run, '6. Stop/end date year before MS onset year', COUNT(*)
    FROM patient
    WHERE stop_or_end_date IS NOT NULL
      AND ms_onset_year IS NOT NULL
      AND EXTRACT(YEAR FROM stop_or_end_date) < ms_onset_year;

    SELECT SUM(issue_count) INTO v_total FROM dq_issue_log WHERE run_at = v_run;
    RAISE NOTICE 'Data-quality run finished: % issues found across 6 checks', v_total;
END
$$;


ALTER PROCEDURE public.sp_run_data_quality_checks() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: age_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.age_group (
    age_group_id smallint NOT NULL,
    age_range text NOT NULL
);


ALTER TABLE public.age_group OWNER TO postgres;

--
-- Name: comorbidity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comorbidity (
    comorbidity_id smallint NOT NULL,
    comorbidity_name text NOT NULL
);


ALTER TABLE public.comorbidity OWNER TO postgres;

--
-- Name: comorbidity_comorbidity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.comorbidity ALTER COLUMN comorbidity_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.comorbidity_comorbidity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: covid_case; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.covid_case (
    patient_id text NOT NULL,
    diagnosis text NOT NULL,
    confirmed_case boolean,
    has_symptoms boolean,
    self_isolated boolean,
    hospitalised boolean,
    icu_stay boolean,
    ventilated boolean,
    recovered text,
    outcome_level_id smallint,
    CONSTRAINT covid_case_diagnosis_check CHECK ((diagnosis = ANY (ARRAY['confirmed'::text, 'suspected'::text, 'not_suspected'::text])))
);


ALTER TABLE public.covid_case OWNER TO postgres;

--
-- Name: covid_case_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.covid_case_audit (
    audit_id bigint NOT NULL,
    patient_id text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    changed_by text DEFAULT CURRENT_USER NOT NULL,
    old_hospitalised boolean,
    new_hospitalised boolean,
    old_outcome_level smallint,
    new_outcome_level smallint
);


ALTER TABLE public.covid_case_audit OWNER TO postgres;

--
-- Name: covid_case_audit_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.covid_case_audit ALTER COLUMN audit_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.covid_case_audit_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: covid_ms_clean; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.covid_ms_clean (
    secret_name text NOT NULL,
    report_source text,
    age_in_cat smallint,
    bmi_in_cat2 text,
    covid19_admission_hospital boolean,
    covid19_confirmed_case boolean,
    covid19_diagnosis text,
    covid19_has_symptoms boolean,
    covid19_icu_stay boolean,
    covid19_outcome_recovered text,
    covid19_self_isolation boolean,
    covid19_sympt_chills boolean,
    covid19_sympt_dry_cough boolean,
    covid19_sympt_fatigue boolean,
    covid19_sympt_fever boolean,
    covid19_sympt_loss_smell_taste boolean,
    covid19_sympt_nasal_congestion boolean,
    covid19_sympt_pain boolean,
    covid19_sympt_pneumonia boolean,
    covid19_sympt_shortness_breath boolean,
    covid19_sympt_sore_throat boolean,
    covid19_ventilation boolean,
    current_dmt text,
    dmt_glucocorticoid boolean,
    edss_in_cat2 smallint,
    has_comorbidities boolean,
    pregnancy boolean,
    sex text,
    year_onset smallint,
    ms_type2 text,
    current_or_former_smoker boolean,
    dmt_type_overall text,
    dmt_drug text,
    covid19_outcome_levels_2 smallint,
    duration_treatment_cat2 smallint,
    com_cardiovascular_disease boolean,
    com_chronic_kidney_disease boolean,
    com_chronic_liver_disease boolean,
    com_diabetes boolean,
    com_hypertension boolean,
    com_immunodeficiency boolean,
    com_lung_disease boolean,
    com_malignancy boolean,
    com_neurological_neuromuscular boolean,
    stop_or_end_date_combined date,
    comorbidities_other smallint,
    dq_symptom_conflict boolean DEFAULT false,
    dq_comorb_unspecified boolean DEFAULT false
);


ALTER TABLE public.covid_ms_clean OWNER TO postgres;

--
-- Name: covid_ms_raw; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.covid_ms_raw (
    secret_name text,
    report_source text,
    age_in_cat text,
    bmi_in_cat2 text,
    covid19_admission_hospital text,
    covid19_confirmed_case text,
    covid19_diagnosis text,
    covid19_has_symptoms text,
    covid19_icu_stay text,
    covid19_outcome_recovered text,
    covid19_self_isolation text,
    covid19_sympt_chills text,
    covid19_sympt_dry_cough text,
    covid19_sympt_fatigue text,
    covid19_sympt_fever text,
    covid19_sympt_loss_smell_taste text,
    covid19_sympt_nasal_congestion text,
    covid19_sympt_pain text,
    covid19_sympt_pneumonia text,
    covid19_sympt_shortness_breath text,
    covid19_sympt_sore_throat text,
    covid19_ventilation text,
    current_dmt text,
    dmt_glucocorticoid text,
    edss_in_cat2 text,
    has_comorbidities text,
    pregnancy text,
    sex text,
    year_onset text,
    ms_type2 text,
    current_or_former_smoker text,
    dmt_type_overall text,
    covid19_outcome_levels_2 text,
    duration_treatment_cat2 text,
    com_cardiovascular_disease text,
    has_comorbidities_1 text,
    has_comorbidities_2 text,
    com_chronic_kidney_disease text,
    com_chronic_liver_disease text,
    com_diabetes text,
    com_hypertension text,
    com_immunodeficiency text,
    com_lung_disease text,
    com_malignancy text,
    com_neurological_neuromuscular text,
    stop_or_end_date_combined text,
    comorbidities_other text
);


ALTER TABLE public.covid_ms_raw OWNER TO postgres;

--
-- Name: dmt_drug; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dmt_drug (
    dmt_id smallint NOT NULL,
    dmt_name text NOT NULL,
    dmt_class text NOT NULL
);


ALTER TABLE public.dmt_drug OWNER TO postgres;

--
-- Name: dmt_drug_dmt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dmt_drug ALTER COLUMN dmt_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.dmt_drug_dmt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dmt_hierarchy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dmt_hierarchy (
    node_id smallint NOT NULL,
    parent_id smallint,
    node_name text NOT NULL,
    dmt_id smallint
);


ALTER TABLE public.dmt_hierarchy OWNER TO postgres;

--
-- Name: dmt_hierarchy_node_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dmt_hierarchy ALTER COLUMN node_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.dmt_hierarchy_node_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dq_issue_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dq_issue_log (
    log_id bigint NOT NULL,
    run_at timestamp with time zone NOT NULL,
    check_name text NOT NULL,
    issue_count bigint NOT NULL
);


ALTER TABLE public.dq_issue_log OWNER TO postgres;

--
-- Name: dq_issue_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dq_issue_log ALTER COLUMN log_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.dq_issue_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: outcome_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.outcome_level (
    outcome_level_id smallint NOT NULL,
    outcome_desc text NOT NULL
);


ALTER TABLE public.outcome_level OWNER TO postgres;

--
-- Name: patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient (
    patient_id text NOT NULL,
    report_source text NOT NULL,
    sex text NOT NULL,
    age_group_id smallint NOT NULL,
    bmi_category text,
    pregnancy boolean,
    smoker boolean NOT NULL,
    ms_type text NOT NULL,
    ms_onset_year smallint,
    edss_cat smallint,
    current_dmt_status text NOT NULL,
    dmt_id smallint,
    on_glucocorticoid boolean,
    treatment_duration_cat smallint,
    stop_or_end_date date,
    has_comorbidities boolean,
    CONSTRAINT patient_current_dmt_status_check CHECK ((current_dmt_status = ANY (ARRAY['yes'::text, 'no'::text, 'never_treated'::text]))),
    CONSTRAINT patient_report_source_check CHECK ((report_source = ANY (ARRAY['patients'::text, 'clinicians'::text]))),
    CONSTRAINT patient_sex_check CHECK ((sex = ANY (ARRAY['female'::text, 'male'::text])))
);


ALTER TABLE public.patient OWNER TO postgres;

--
-- Name: patient_comorbidity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_comorbidity (
    patient_id text NOT NULL,
    comorbidity_id smallint NOT NULL,
    present boolean NOT NULL
);


ALTER TABLE public.patient_comorbidity OWNER TO postgres;

--
-- Name: patient_symptom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_symptom (
    patient_id text NOT NULL,
    symptom_id smallint NOT NULL,
    present boolean NOT NULL
);


ALTER TABLE public.patient_symptom OWNER TO postgres;

--
-- Name: rpt_outcome_summary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rpt_outcome_summary (
    dimension text,
    group_label text,
    cohort_patients bigint,
    hospitalised bigint,
    hosp_rate_pct numeric,
    refreshed_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rpt_outcome_summary OWNER TO postgres;

--
-- Name: symptom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.symptom (
    symptom_id smallint NOT NULL,
    symptom_name text NOT NULL
);


ALTER TABLE public.symptom OWNER TO postgres;

--
-- Name: symptom_symptom_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.symptom ALTER COLUMN symptom_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.symptom_symptom_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_covid_cohort; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_covid_cohort AS
 SELECT p.patient_id,
    p.report_source,
    p.sex,
    ag.age_range,
    p.ms_type,
    p.ms_onset_year,
    p.bmi_category,
    p.has_comorbidities,
    p.current_dmt_status,
    d.dmt_name,
    d.dmt_class,
    cc.diagnosis,
    cc.hospitalised,
    cc.outcome_level_id,
    COALESCE(sc.symptom_count, (0)::bigint) AS symptom_count
   FROM ((((public.patient p
     JOIN public.covid_case cc ON ((cc.patient_id = p.patient_id)))
     JOIN public.age_group ag ON ((ag.age_group_id = p.age_group_id)))
     LEFT JOIN public.dmt_drug d ON ((d.dmt_id = p.dmt_id)))
     LEFT JOIN ( SELECT patient_symptom.patient_id,
            count(*) AS symptom_count
           FROM public.patient_symptom
          WHERE patient_symptom.present
          GROUP BY patient_symptom.patient_id) sc ON ((sc.patient_id = p.patient_id)))
  WHERE (cc.diagnosis = ANY (ARRAY['confirmed'::text, 'suspected'::text]));


ALTER VIEW public.v_covid_cohort OWNER TO postgres;

--
-- Data for Name: age_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.age_group (age_group_id, age_range) FROM stdin;
\.
COPY public.age_group (age_group_id, age_range) FROM '$$PATH$$/5169.dat';

--
-- Data for Name: comorbidity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comorbidity (comorbidity_id, comorbidity_name) FROM stdin;
\.
COPY public.comorbidity (comorbidity_id, comorbidity_name) FROM '$$PATH$$/5176.dat';

--
-- Data for Name: covid_case; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.covid_case (patient_id, diagnosis, confirmed_case, has_symptoms, self_isolated, hospitalised, icu_stay, ventilated, recovered, outcome_level_id) FROM stdin;
\.
COPY public.covid_case (patient_id, diagnosis, confirmed_case, has_symptoms, self_isolated, hospitalised, icu_stay, ventilated, recovered, outcome_level_id) FROM '$$PATH$$/5178.dat';

--
-- Data for Name: covid_case_audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.covid_case_audit (audit_id, patient_id, changed_at, changed_by, old_hospitalised, new_hospitalised, old_outcome_level, new_outcome_level) FROM stdin;
\.
COPY public.covid_case_audit (audit_id, patient_id, changed_at, changed_by, old_hospitalised, new_hospitalised, old_outcome_level, new_outcome_level) FROM '$$PATH$$/5187.dat';

--
-- Data for Name: covid_ms_clean; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.covid_ms_clean (secret_name, report_source, age_in_cat, bmi_in_cat2, covid19_admission_hospital, covid19_confirmed_case, covid19_diagnosis, covid19_has_symptoms, covid19_icu_stay, covid19_outcome_recovered, covid19_self_isolation, covid19_sympt_chills, covid19_sympt_dry_cough, covid19_sympt_fatigue, covid19_sympt_fever, covid19_sympt_loss_smell_taste, covid19_sympt_nasal_congestion, covid19_sympt_pain, covid19_sympt_pneumonia, covid19_sympt_shortness_breath, covid19_sympt_sore_throat, covid19_ventilation, current_dmt, dmt_glucocorticoid, edss_in_cat2, has_comorbidities, pregnancy, sex, year_onset, ms_type2, current_or_former_smoker, dmt_type_overall, dmt_drug, covid19_outcome_levels_2, duration_treatment_cat2, com_cardiovascular_disease, com_chronic_kidney_disease, com_chronic_liver_disease, com_diabetes, com_hypertension, com_immunodeficiency, com_lung_disease, com_malignancy, com_neurological_neuromuscular, stop_or_end_date_combined, comorbidities_other, dq_symptom_conflict, dq_comorb_unspecified) FROM stdin;
\.
COPY public.covid_ms_clean (secret_name, report_source, age_in_cat, bmi_in_cat2, covid19_admission_hospital, covid19_confirmed_case, covid19_diagnosis, covid19_has_symptoms, covid19_icu_stay, covid19_outcome_recovered, covid19_self_isolation, covid19_sympt_chills, covid19_sympt_dry_cough, covid19_sympt_fatigue, covid19_sympt_fever, covid19_sympt_loss_smell_taste, covid19_sympt_nasal_congestion, covid19_sympt_pain, covid19_sympt_pneumonia, covid19_sympt_shortness_breath, covid19_sympt_sore_throat, covid19_ventilation, current_dmt, dmt_glucocorticoid, edss_in_cat2, has_comorbidities, pregnancy, sex, year_onset, ms_type2, current_or_former_smoker, dmt_type_overall, dmt_drug, covid19_outcome_levels_2, duration_treatment_cat2, com_cardiovascular_disease, com_chronic_kidney_disease, com_chronic_liver_disease, com_diabetes, com_hypertension, com_immunodeficiency, com_lung_disease, com_malignancy, com_neurological_neuromuscular, stop_or_end_date_combined, comorbidities_other, dq_symptom_conflict, dq_comorb_unspecified) FROM '$$PATH$$/5168.dat';

--
-- Data for Name: covid_ms_raw; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.covid_ms_raw (secret_name, report_source, age_in_cat, bmi_in_cat2, covid19_admission_hospital, covid19_confirmed_case, covid19_diagnosis, covid19_has_symptoms, covid19_icu_stay, covid19_outcome_recovered, covid19_self_isolation, covid19_sympt_chills, covid19_sympt_dry_cough, covid19_sympt_fatigue, covid19_sympt_fever, covid19_sympt_loss_smell_taste, covid19_sympt_nasal_congestion, covid19_sympt_pain, covid19_sympt_pneumonia, covid19_sympt_shortness_breath, covid19_sympt_sore_throat, covid19_ventilation, current_dmt, dmt_glucocorticoid, edss_in_cat2, has_comorbidities, pregnancy, sex, year_onset, ms_type2, current_or_former_smoker, dmt_type_overall, covid19_outcome_levels_2, duration_treatment_cat2, com_cardiovascular_disease, has_comorbidities_1, has_comorbidities_2, com_chronic_kidney_disease, com_chronic_liver_disease, com_diabetes, com_hypertension, com_immunodeficiency, com_lung_disease, com_malignancy, com_neurological_neuromuscular, stop_or_end_date_combined, comorbidities_other) FROM stdin;
\.
COPY public.covid_ms_raw (secret_name, report_source, age_in_cat, bmi_in_cat2, covid19_admission_hospital, covid19_confirmed_case, covid19_diagnosis, covid19_has_symptoms, covid19_icu_stay, covid19_outcome_recovered, covid19_self_isolation, covid19_sympt_chills, covid19_sympt_dry_cough, covid19_sympt_fatigue, covid19_sympt_fever, covid19_sympt_loss_smell_taste, covid19_sympt_nasal_congestion, covid19_sympt_pain, covid19_sympt_pneumonia, covid19_sympt_shortness_breath, covid19_sympt_sore_throat, covid19_ventilation, current_dmt, dmt_glucocorticoid, edss_in_cat2, has_comorbidities, pregnancy, sex, year_onset, ms_type2, current_or_former_smoker, dmt_type_overall, covid19_outcome_levels_2, duration_treatment_cat2, com_cardiovascular_disease, has_comorbidities_1, has_comorbidities_2, com_chronic_kidney_disease, com_chronic_liver_disease, com_diabetes, com_hypertension, com_immunodeficiency, com_lung_disease, com_malignancy, com_neurological_neuromuscular, stop_or_end_date_combined, comorbidities_other) FROM '$$PATH$$/5167.dat';

--
-- Data for Name: dmt_drug; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dmt_drug (dmt_id, dmt_name, dmt_class) FROM stdin;
\.
COPY public.dmt_drug (dmt_id, dmt_name, dmt_class) FROM '$$PATH$$/5172.dat';

--
-- Data for Name: dmt_hierarchy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dmt_hierarchy (node_id, parent_id, node_name, dmt_id) FROM stdin;
\.
COPY public.dmt_hierarchy (node_id, parent_id, node_name, dmt_id) FROM '$$PATH$$/5185.dat';

--
-- Data for Name: dq_issue_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dq_issue_log (log_id, run_at, check_name, issue_count) FROM stdin;
\.
COPY public.dq_issue_log (log_id, run_at, check_name, issue_count) FROM '$$PATH$$/5183.dat';

--
-- Data for Name: outcome_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.outcome_level (outcome_level_id, outcome_desc) FROM stdin;
\.
COPY public.outcome_level (outcome_level_id, outcome_desc) FROM '$$PATH$$/5170.dat';

--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient (patient_id, report_source, sex, age_group_id, bmi_category, pregnancy, smoker, ms_type, ms_onset_year, edss_cat, current_dmt_status, dmt_id, on_glucocorticoid, treatment_duration_cat, stop_or_end_date, has_comorbidities) FROM stdin;
\.
COPY public.patient (patient_id, report_source, sex, age_group_id, bmi_category, pregnancy, smoker, ms_type, ms_onset_year, edss_cat, current_dmt_status, dmt_id, on_glucocorticoid, treatment_duration_cat, stop_or_end_date, has_comorbidities) FROM '$$PATH$$/5177.dat';

--
-- Data for Name: patient_comorbidity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_comorbidity (patient_id, comorbidity_id, present) FROM stdin;
\.
COPY public.patient_comorbidity (patient_id, comorbidity_id, present) FROM '$$PATH$$/5180.dat';

--
-- Data for Name: patient_symptom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_symptom (patient_id, symptom_id, present) FROM stdin;
\.
COPY public.patient_symptom (patient_id, symptom_id, present) FROM '$$PATH$$/5179.dat';

--
-- Data for Name: rpt_outcome_summary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rpt_outcome_summary (dimension, group_label, cohort_patients, hospitalised, hosp_rate_pct, refreshed_at) FROM stdin;
\.
COPY public.rpt_outcome_summary (dimension, group_label, cohort_patients, hospitalised, hosp_rate_pct, refreshed_at) FROM '$$PATH$$/5181.dat';

--
-- Data for Name: symptom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.symptom (symptom_id, symptom_name) FROM stdin;
\.
COPY public.symptom (symptom_id, symptom_name) FROM '$$PATH$$/5174.dat';

--
-- Name: comorbidity_comorbidity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comorbidity_comorbidity_id_seq', 10, true);


--
-- Name: covid_case_audit_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.covid_case_audit_audit_id_seq', 4, true);


--
-- Name: dmt_drug_dmt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dmt_drug_dmt_id_seq', 13, true);


--
-- Name: dmt_hierarchy_node_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dmt_hierarchy_node_id_seq', 16, true);


--
-- Name: dq_issue_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dq_issue_log_log_id_seq', 6, true);


--
-- Name: symptom_symptom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.symptom_symptom_id_seq', 10, true);


--
-- Name: age_group age_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.age_group
    ADD CONSTRAINT age_group_pkey PRIMARY KEY (age_group_id);


--
-- Name: comorbidity comorbidity_comorbidity_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comorbidity
    ADD CONSTRAINT comorbidity_comorbidity_name_key UNIQUE (comorbidity_name);


--
-- Name: comorbidity comorbidity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comorbidity
    ADD CONSTRAINT comorbidity_pkey PRIMARY KEY (comorbidity_id);


--
-- Name: covid_case_audit covid_case_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.covid_case_audit
    ADD CONSTRAINT covid_case_audit_pkey PRIMARY KEY (audit_id);


--
-- Name: covid_case covid_case_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.covid_case
    ADD CONSTRAINT covid_case_pkey PRIMARY KEY (patient_id);


--
-- Name: covid_ms_clean covid_ms_clean_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.covid_ms_clean
    ADD CONSTRAINT covid_ms_clean_pkey PRIMARY KEY (secret_name);


--
-- Name: dmt_drug dmt_drug_dmt_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dmt_drug
    ADD CONSTRAINT dmt_drug_dmt_name_key UNIQUE (dmt_name);


--
-- Name: dmt_drug dmt_drug_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dmt_drug
    ADD CONSTRAINT dmt_drug_pkey PRIMARY KEY (dmt_id);


--
-- Name: dmt_hierarchy dmt_hierarchy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dmt_hierarchy
    ADD CONSTRAINT dmt_hierarchy_pkey PRIMARY KEY (node_id);


--
-- Name: dq_issue_log dq_issue_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dq_issue_log
    ADD CONSTRAINT dq_issue_log_pkey PRIMARY KEY (log_id);


--
-- Name: outcome_level outcome_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.outcome_level
    ADD CONSTRAINT outcome_level_pkey PRIMARY KEY (outcome_level_id);


--
-- Name: patient_comorbidity patient_comorbidity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_comorbidity
    ADD CONSTRAINT patient_comorbidity_pkey PRIMARY KEY (patient_id, comorbidity_id);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (patient_id);


--
-- Name: patient_symptom patient_symptom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_symptom
    ADD CONSTRAINT patient_symptom_pkey PRIMARY KEY (patient_id, symptom_id);


--
-- Name: symptom symptom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.symptom
    ADD CONSTRAINT symptom_pkey PRIMARY KEY (symptom_id);


--
-- Name: symptom symptom_symptom_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.symptom
    ADD CONSTRAINT symptom_symptom_name_key UNIQUE (symptom_name);


--
-- Name: idx_case_diagnosis; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_diagnosis ON public.covid_case USING btree (diagnosis);


--
-- Name: idx_case_outcome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_case_outcome ON public.covid_case USING btree (outcome_level_id);


--
-- Name: idx_dmt_hierarchy_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dmt_hierarchy_parent ON public.dmt_hierarchy USING btree (parent_id);


--
-- Name: idx_patient_age_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_age_group ON public.patient USING btree (age_group_id);


--
-- Name: idx_patient_dmt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_dmt ON public.patient USING btree (dmt_id);


--
-- Name: idx_pc_comorb_yes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pc_comorb_yes ON public.patient_comorbidity USING btree (comorbidity_id) WHERE present;


--
-- Name: idx_ps_symptom_yes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ps_symptom_yes ON public.patient_symptom USING btree (symptom_id) WHERE present;


--
-- Name: covid_case tr_covid_case_audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tr_covid_case_audit AFTER UPDATE ON public.covid_case FOR EACH ROW EXECUTE FUNCTION public.fn_audit_covid_case();


--
-- Name: covid_case tr_sync_outcome_level; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tr_sync_outcome_level BEFORE INSERT OR UPDATE ON public.covid_case FOR EACH ROW EXECUTE FUNCTION public.fn_sync_outcome_level();


--
-- Name: covid_case tr_validate_covid_case; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tr_validate_covid_case BEFORE INSERT OR UPDATE ON public.covid_case FOR EACH ROW EXECUTE FUNCTION public.fn_validate_covid_case();


--
-- Name: covid_case covid_case_outcome_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.covid_case
    ADD CONSTRAINT covid_case_outcome_level_id_fkey FOREIGN KEY (outcome_level_id) REFERENCES public.outcome_level(outcome_level_id);


--
-- Name: covid_case covid_case_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.covid_case
    ADD CONSTRAINT covid_case_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(patient_id);


--
-- Name: dmt_hierarchy dmt_hierarchy_dmt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dmt_hierarchy
    ADD CONSTRAINT dmt_hierarchy_dmt_id_fkey FOREIGN KEY (dmt_id) REFERENCES public.dmt_drug(dmt_id);


--
-- Name: dmt_hierarchy dmt_hierarchy_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dmt_hierarchy
    ADD CONSTRAINT dmt_hierarchy_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.dmt_hierarchy(node_id);


--
-- Name: patient patient_age_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_age_group_id_fkey FOREIGN KEY (age_group_id) REFERENCES public.age_group(age_group_id);


--
-- Name: patient_comorbidity patient_comorbidity_comorbidity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_comorbidity
    ADD CONSTRAINT patient_comorbidity_comorbidity_id_fkey FOREIGN KEY (comorbidity_id) REFERENCES public.comorbidity(comorbidity_id);


--
-- Name: patient_comorbidity patient_comorbidity_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_comorbidity
    ADD CONSTRAINT patient_comorbidity_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(patient_id);


--
-- Name: patient patient_dmt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_dmt_id_fkey FOREIGN KEY (dmt_id) REFERENCES public.dmt_drug(dmt_id);


--
-- Name: patient_symptom patient_symptom_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_symptom
    ADD CONSTRAINT patient_symptom_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(patient_id);


--
-- Name: patient_symptom patient_symptom_symptom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_symptom
    ADD CONSTRAINT patient_symptom_symptom_id_fkey FOREIGN KEY (symptom_id) REFERENCES public.symptom(symptom_id);


--
-- PostgreSQL database dump complete
--

